package Data_Structures;

public class isBSTReturnType {

	boolean isBst;
	int min;
	int max;
	
}
