package Data_Structures;

public class BinarySearchTreeUse {
	
	public static BinaryTreeNode<Integer> findNode(BinaryTreeNode<Integer> root,int num){
		if(root == null){
			return null;
		}
		if(root.data == num){
			return root;
		}
		
		if(num < root.data){
			return findNode(root.left, num);
		}
		else{
			return findNode(root.right, num);
		}
	}
	
	public static isBSTReturnType checkBST(BinaryTreeNode<Integer> root){
		
		if(root == null){
			isBSTReturnType output = new isBSTReturnType();
			output.isBst = true;
			output.min = Integer.MAX_VALUE;
			output.max = Integer.MIN_VALUE;
			return output;
		}
		isBSTReturnType leftOutput = checkBST(root.left);
		isBSTReturnType rightOutput = checkBST(root.right);
		if(!leftOutput.isBst || !rightOutput.isBst ){
			isBSTReturnType output = new isBSTReturnType();
			output.isBst = false;
			return output;
		}
		if(leftOutput.max > root.data || rightOutput.min < root.data){
			isBSTReturnType output = new isBSTReturnType();
			output.isBst = false;
			return output;
		}
		isBSTReturnType output = new isBSTReturnType();
		output.isBst = true;
		output.min = Integer.min(leftOutput.min, root.data);
		output.max = Integer.max(rightOutput.max, root.data);
		return output;
	}
	
	public static boolean checkBST3(BinaryTreeNode<Integer> root,int min,int max){
		if(root == null){
			return true;
		}
		
		if(root.data < min || root.data > max){
			return false;
		}
		
		return checkBST3(root.left, min, root.data) && checkBST3(root.right, root.data, max);
	}
	
	public static void main(String[] args) throws Exception {
		BinaryTreeNode<Integer> root = BinaryTreeUse.takeInput();
		checkBST3(root, Integer.MIN_VALUE, Integer.MAX_VALUE);

	}

}
