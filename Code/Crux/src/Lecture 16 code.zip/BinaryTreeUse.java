package Data_Structures;

import java.util.ArrayList;
import java.util.Scanner;

public class BinaryTreeUse {


	public static BinaryTreeNode<Integer> takeInput() throws Exception{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter root data :");
		int rootData = s.nextInt();
		BinaryTreeNode<Integer> root = new BinaryTreeNode<>();
		root.data = rootData;

		QueueUsingLL<BinaryTreeNode<Integer>> pendingNodes = new QueueUsingLL<>();
		pendingNodes.enqueue(root);
		while(!pendingNodes.isEmpty()){
			BinaryTreeNode<Integer> currentNode = pendingNodes.dequeue();
			System.out.println("Enter left child of " + currentNode.data);
			int leftData = s.nextInt();
			if(leftData != -1){
				BinaryTreeNode<Integer> leftChild = new BinaryTreeNode<>();
				leftChild.data = leftData;
				currentNode.left = leftChild;
				pendingNodes.enqueue(leftChild);
			}
			System.out.println("Enter right child of " + currentNode.data);
			int rightData = s.nextInt();
			if(rightData != -1){
				BinaryTreeNode<Integer> rightChild = new BinaryTreeNode<>();
				rightChild.data = rightData;
				currentNode.right = rightChild;
				pendingNodes.enqueue(rightChild);
			}
		}

		return root;

	}


	public static void print(BinaryTreeNode<Integer> root){

		if(root == null){
			return;
		}
		//	System.out.println(root.data +" : "+root.left.data +", "+ root.right.data);

		String toBePrinted = root.data +" : ";
		if(root.left != null){
			toBePrinted+= root.left.data +", ";
		}
		if(root.right != null){
			toBePrinted+= root.right.data +", ";
		}
		System.out.println(toBePrinted);
		print(root.left);
		print(root.right);

	}

	public static int height(BinaryTreeNode<Integer> root){
		if(root == null){
			return 0;
		}
	
		return Integer.max(height(root.left) ,height(root.right)) + 1; 	
	}


	public static int diameter(BinaryTreeNode<Integer> root){

		if(root == null){
			return 0;
		}

		int leftHeight = height(root.left);
		int rightHeight = height(root.right);
		int leftDiameter = diameter(root.left);
		int rightDiameter = diameter(root.right);

		return Integer.max(Integer.max(leftDiameter, rightDiameter), leftHeight + rightHeight + 1);

	}

	public static BTPair diameterFaster(BinaryTreeNode<Integer> root){
		if(root == null){
			BTPair result = new BTPair(0,0);
			return result;
		}

		BTPair leftPair = diameterFaster(root.left);
		BTPair rightPair = diameterFaster(root.right);
		int treeHeight = Integer.max(leftPair.height, rightPair.height) + 1;
		int treeDiameter = Integer.max(Integer.max(leftPair.diameter, rightPair.diameter), leftPair.height + rightPair.height + 1);
		BTPair result = new BTPair(treeHeight,treeDiameter);
		return result;

	}

	public static BinaryTreeNode<Integer> constructFromPreIn(int[] pre, int[] in,int inS,int inE,
			int preS, int preE){
		if(inS > inE){
			return null;
		}
		BinaryTreeNode<Integer> root = new BinaryTreeNode<>();
		root.data = pre[preS];
		int i;
	
		for( i = inS; i <= inE; i++){
			if(root.data == in[i]){
				break;
			}
		}
		
		int leftInS = inS;
		int leftInE = i - 1;
		int rightInS = i + 1;
		int rightInE = inE;
		
		int leftPreS = preS + 1;
		int rightPreE = preE;
		int leftLength = leftInE - leftInS + 1;
		int leftPreE =  leftPreS + leftLength -  1;
		int rightPreS = leftPreE + 1;
		
		root.left = constructFromPreIn(pre, in, leftInS, leftInE, leftPreS, leftPreE);
		root.right = constructFromPreIn(pre, in, rightInS, rightInE, rightPreS, rightPreE);
		
		return root;
	}

	
	public static ArrayList<Node<BinaryTreeNode<Integer>>> LLForEachLevel(BinaryTreeNode<Integer> root) throws Exception{
		if(root == null){
			return null;
		}
		ArrayList<Node<BinaryTreeNode<Integer>>> output = new ArrayList<>();
		QueueUsingLL<BinaryTreeNode<Integer>> primary = new QueueUsingLL<>();
		QueueUsingLL<BinaryTreeNode<Integer>> secondary = new QueueUsingLL<>();
		primary.enqueue(root);
		Node<BinaryTreeNode<Integer>> head = null,tail = null;
		while(!primary.isEmpty()){
			BinaryTreeNode<Integer> currentNode = primary.dequeue();
			Node<BinaryTreeNode<Integer>> newNode = new Node<>();
			newNode.data = currentNode;
			if(head == null){
				head = newNode;
				tail = newNode;
			}
			else{
				tail.next = newNode;
				tail = newNode;
			}
			if(currentNode.left != null){
				secondary.enqueue(currentNode.left);
			}
			if(currentNode.right != null){
				secondary.enqueue(currentNode.right);
			}
			if(primary.isEmpty()){
				output.add(head);
				QueueUsingLL<BinaryTreeNode<Integer>> temp = primary;
				primary = secondary;
				secondary = temp;
				head = null;
				tail = null;	
			}
			
			
		}
		return output;
	}
	
	
	public static boolean checkBalanced(BinaryTreeNode<Integer> root){
		
		if(root == null){
			return true;
		}
		
		int leftHeight = height(root.left);
		int rightHeight = height(root.right);
		if(Math.abs(leftHeight - rightHeight) > 1){
			return false;
		}
		
		return checkBalanced(root.left) && checkBalanced(root.right);
		
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		/*BinaryTreeNode<Integer> root = takeInput();
		BTPair result = diameterFaster(root);
		System.out.println(result.diameter);*/
		
		int pre[] = {1,2,4,5,3,6,7};
		int in[] = {4,2,5,1,6,3,7};
		BinaryTreeNode<Integer> root = constructFromPreIn(pre, in, 0, in.length-1, 0, pre.length - 1);
		print(root);
	}

}
