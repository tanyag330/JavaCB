import java.util.Scanner;


public class positive_negative_sum {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
	      sumposneg(array);
		
	}
	public static void sumposneg(int input[]){
		int pos=0,neg=0;
		for(int i=0;i<input.length;i++)
		{
			if(input[i]>=0)
				pos=pos+input[i];
			else
				neg=neg+input[i];
		}
		System.out.print("positive sum is "+ pos);
		System.out.print("negative sum is "+ neg);

		
	}


}
