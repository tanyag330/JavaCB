import java.util.Scanner;


public class decimal_to_binary_array {
   public static void main(String[] args) {		
	   Scanner s=new Scanner(System.in);        
        System.out.print("Enter a number: ");
        int num = s.nextInt();
        s.close();
        stringtobinary(num);

    }
	
	public static void stringtobinary(int n) {
	      int[] array=new int[10];
	      int f=0;
	      
	      while(n>=1)
	      {
	    	  if(n%2==0)
	    	  {
	    		  n=n/2;
	    		  array[f]=0;
                  f++;	    	  
	    	  }
	    	  else
	    	  {
	    		  n=n/2;
	    		  array[f]=1;
	    		  f++;
	    	  }
	      }
	      for(int i=f-1;i>=0;i--)
	      {
	    	  System.out.print(array[i]);
	      }
	      
		
	 }
}
