import java.util.Scanner;


public class sum_of_array {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of first array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		System.out.print("Enter the size of second array");
		int size1=s.nextInt();
		int[] arrays=new int[size1];
		System.out.print("Enter the values");
		for(int i=0;i<size1;i++)
		{
			arrays[i]=s.nextInt();
		}
		sum(array,arrays,size,size1);		
	}
	public static void sum(int input[],int input1[],int s,int s1){
		int c;
		if(s>=s1)
		c=s;
		else
	    c=s1;
		int[] ans=new int[c];
		
		for(int i=0;i<c;i++)
		{
			ans[i]=input[i]+input[i];
		}
		System.out.print("sum of both arrays are");
		for(int i=0;i<c;i++)
		{
			System.out.print(ans[i]);

		}
		
		
	}
}
