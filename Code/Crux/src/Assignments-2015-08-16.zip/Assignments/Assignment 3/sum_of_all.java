import java.util.Scanner;


public class sum_of_all {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		int k= sum(array);
		System.out.print("laregst number is "+ k);
		
	}
	public static int sum(int input[]){
		int sum=0;
		for(int i=0;i<input.length;i++)
		{
			sum+=input[i];
		}
		return sum;
		
	}

}
