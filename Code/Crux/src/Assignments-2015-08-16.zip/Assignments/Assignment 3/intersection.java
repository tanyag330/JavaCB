import java.util.Scanner;


public class intersection {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of first array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		System.out.print("Enter the size of second array");
		int size1=s.nextInt();
		int[] arrays=new int[size1];
		System.out.print("Enter the values");
		for(int i=0;i<size1;i++)
		{
			arrays[i]=s.nextInt();
		}
		intersect(array,arrays);		
	}
	public static void intersect(int input[],int input1[]){
		
		for(int i=0;i<input.length;i++)
		{
			for(int j=0;j<input1.length;j++)
			{
				if(input[i]==input1[j])
				{
					System.out.print(input[i]);
				}
			}
		}
		
		
	}

}
