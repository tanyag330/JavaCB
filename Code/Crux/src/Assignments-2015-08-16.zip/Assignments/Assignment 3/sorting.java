import java.util.Scanner;


public class sorting {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		sorting(array);		
	}
	public static void sorting(int array[])
	{
		int max=array[0],pos=0;
		for(int i=0;i<array.length;i++)
		{pos=i;
			max=array[i];
			for(int j=i+1;j<array.length;j++)
			{ 
				
				if(max<array[j])
				{
				   max=array[j];
				    pos=j;
				}
				
			}
			int temp=array[i];
			array[i]=max;
			array[pos]=temp;
		}
		for(int i=0;i<array.length;i++)
		{
			System.out.print(array[i]+" ");
		}
	}

}
