import java.util.Scanner;


public class duplicate {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		
	}
	public static void duplicate(int input[]){
		int f=1;
		int c=input.length;
		
		for(int i=0;i<input.length;i++)
		{
			for(int j=i+1;j<input.length;j++)
			{
				if(input[i]==input[j])
				{    c--;
					for(f=1;f<c;f++)
					{
						input[i]=input[i+f];
						System.out.print(input[i]+" ");

	
					}
				}
				
			}
		}
		for(int i=0;i<c;i++)
			System.out.print(input[i]+" ");
		
	}

}
