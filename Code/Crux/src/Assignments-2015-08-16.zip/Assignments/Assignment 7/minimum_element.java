import java.util.Scanner;


public class minimum_element {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("write total entry ");
		int size=s.nextInt();
		System.out.println("Enter values");
		int[] entry=new int[size];
		for(int i=0;i<size;i++)
		{
			entry[i]=s.nextInt();
		}
		s.close();
		int min=entry[0];
		System.out.print(minimum(entry,size,min));
	}
	public static int minimum(int[] entry,int size,int min)
	{
		if(size<1)
			return min;
		
		if(min>entry[size-1])
		{
			min=entry[size-1];
			return minimum(entry,size-1,min);
		}
		else
			return minimum(entry,size-1,min);
	}

}
