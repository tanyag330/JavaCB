import java.util.Scanner;


public class no_repetition {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=s.nextLine();
		s.close();
		System.out.print(repeatstar(str));

	}
	public static String repeatstar(String str){
		if(str.length()<2)
		{
			return str;
		}
		if(str.charAt(0)==str.charAt(1))
		{
			return repeatstar(str.substring(1));
			
		}
		
			return str.substring(0,1)+repeatstar(str.substring(1));
	

	}

}
