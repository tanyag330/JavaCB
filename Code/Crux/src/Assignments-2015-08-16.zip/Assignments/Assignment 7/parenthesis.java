import java.util.Scanner;


public class parenthesis {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter string 1 ");
		String str=s.nextLine();
		s.close();
		int e=0;
		int k=(integer(str,e));
		if(k==0)
			System.out.print("it is parenthsis");
		else
			System.out.print("it is not parenthsis");


	}
	public static int integer(String str,int s){
		if(str.length()<1)
		{
			return s;
		}
		
		if(str.charAt(0)=='(')
				{
			      return integer(str.substring(1),s+1);
				}
		else if(str.charAt(0)==')')
		{
			return integer(str.substring(1),s-1);
		}
			
		return integer(str.substring(1),s);
	}

}
