import java.util.Scanner;


public class print_between_parenthesis {
	public static void main(String args[]){
	Scanner s=new Scanner(System.in);
	System.out.println("Enter string 1 ");
	String str=s.nextLine();
	s.close();
	System.out.print(integer(str));
}

	public static String integer(String str) 
	 { 
	 	int len = str.length(); 
	 	if(str.charAt(0) != '(') 
	 	{ 
	 		if(str.charAt(len - 1) != ')') 
	 			return integer(str.substring(1, len -1)); 
	 		return integer(str.substring(1)); 
	 	} 
	 	if(str.charAt(len - 1) != ')') 
	 		return integer(str.substring(0, len - 1)); 
	 	return str; 
 	
 } 

}


