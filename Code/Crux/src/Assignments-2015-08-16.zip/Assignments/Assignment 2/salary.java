package assignment2;

import java.util.Scanner;

public class salary {
	public static void main (String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter basic salary = ");
		int basic = s.nextInt();
		System.out.print("Enter grade (A/B/C) = ");
		char grade = s.next().charAt(0);
		s.close();
		int hra = basic/5, da = basic/2, pf = (11/100)*basic, t_sal, allow;
		if (grade == 'A' || grade == 'a')
		{
			allow = 1700;
		}
		else if (grade == 'B' || grade == 'b')
		{
			allow = 1500;
		}
		else if (grade == 'C' || grade == 'c')
		{
			allow = 1300;
		}
		else
		{
			System.out.println("Invalid choice!");
			return;
		}
		t_sal = basic + hra + da + allow - pf;
		System.out.println("Total salary = "+t_sal);
		}

}
