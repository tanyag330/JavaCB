package assignment2;

import java.util.Scanner;

public class average_2_subjects {
	public static void main(String args[]){
	Scanner s = new Scanner(System.in);
	System.out.print("Enter Subject one = ");
	String sub1 = s.next();
	System.out.print("Enter marks = ");
	int marks1 = s.nextInt();
	System.out.print("Enter Subject two = ");
	String sub2 = s.next();
	System.out.print("Enter marks = ");
	int marks2 = s.nextInt();
	System.out.print("Enter Subject three = ");
	String sub3 = s.next();
	System.out.print("Enter marks = ");
	int marks3 = s.nextInt();
	s.close();
	if (marks1<marks2 && marks1<marks3)
	{
		System.out.println("Highest in "+sub2+" and "+sub3);
		System.out.println("Average = "+(float)((marks2+marks3)/2));
	}
	else if (marks2<marks1 && marks2<marks3)
	{
		System.out.println("Highest in "+sub1+" and "+sub3);
		System.out.println("Average = "+(float)((marks1+marks3)/2));
	}
	else
	{
		System.out.println("Highest in "+sub1+" and "+sub2);
		System.out.println("Average = "+(float)((marks1+marks2)/2));
	}
}

}



