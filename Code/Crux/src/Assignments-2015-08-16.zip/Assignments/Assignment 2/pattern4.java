package assignment2;

import java.util.Scanner;

public class pattern4 {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number of rows");
		int num=s.nextInt();
		s.close();
		int d=0;
		int c=2;
		int n=2;
		int f=0;
		System.out.println("1");
		while(c<=num)
		{
		n=1;
		f++;
		d++;
		   while(n<=c)
		{ 
			   if(n==1||n==c)
			System.out.print(d); 
			   else
			   {				 
			System.out.print("0");
			   }
			n++;
			
		}
		   System.out.print("\n");
		   c++;
		   
		}
	}


}
