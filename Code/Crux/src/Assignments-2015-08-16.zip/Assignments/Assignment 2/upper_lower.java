package assignment2;

import java.util.Scanner;

public class upper_lower {

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter a character = ");
		char str = s.next().charAt(0);
		s.close();
		if (str>='a' && str<='z')
		{
			System.out.println("Lower case");
		}
		else if (str>='A' && str<='Z')
		{
			System.out.println("Upper case");
		}
		else
		{
			System.out.println("Invalid Input");
		}
	}

}
