package assignment2;

import java.util.Scanner;

public class quadratic_equation {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("ax^2 + bx + c = 0");
		System.out.print("Enter a = ");
		double a = s.nextDouble();
		System.out.print("Enter b = ");
		double b = s.nextDouble();
		System.out.print("Enter c = ");
		double c = s.nextDouble();
		s.close();
		double root1 = (-b + Math.sqrt(b*b-4*a*c))/2*a;
		double root2 = (-b - Math.sqrt(b*b-4*a*c))/2*a;
		if (b*b<4*a*c){
			System.out.println("No roots");
		}
		else {
			System.out.println("The roots are " + root1 + " & "+ root2 + ".");
		}
	}

}
