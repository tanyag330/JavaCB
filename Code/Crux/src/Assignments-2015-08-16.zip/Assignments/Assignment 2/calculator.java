package assignment2;

import java.util.Scanner;

public class calculator {
	public static void main(String[] args)
	{
		Scanner scanner=new Scanner(System.in);
		String p;
		System.out.println("CALCULATOR");
		do
		{
			System.out.println("");
			System.out.print("1. Addition\n2. Subtraction\n3. Multiplication\n4. Division\n\nEnter your choice = ");
					int i;
					i=scanner.nextInt();
					switch (i)
					{  case 1:
						System.out.print("Enter first number = ");
						int a=scanner.nextInt();
						System.out.print("Enter second number = ");
						int b = scanner.nextInt();
						int c = a+b;
						System.out.println("Sum = "+c);
						break;
					case 2:
						System.out.print("Enter first number = ");
						int d = scanner.nextInt();
						System.out.print("Enter second number = ");
						int e = scanner.nextInt();
						int f = d-e;
						System.out.println("Difference = "+f);
						break;
					case 3:
						System.out.print("Enter first number = ");
						int g = scanner.nextInt();
						System.out.print("Enter second number = ");
						int h = scanner.nextInt();
						int j = g * h;
						System.out.println("Product = "+j);
						break;
					case 4:
						System.out.print("Enter the dividend = ");
						int k = scanner.nextInt();
						System.out.print("Enter the divisor = ");
						int l = scanner.nextInt();
						int m = k/l;
						int n = k%l;
						double o = k/l;
						System.out.println("Quotient = "+m);
						System.out.println("Remainder = "+n);
						System.out.println("Proper Value = "+o);
						break;
					default:
						System.out.println("What are you up to Nigga?");
						break;
					}
					System.out.println("");
					System.out.println("Continue?(y/n)=");
					p = scanner.next();
		}
		while(p.charAt(0) =='y');
		scanner.close();
	}

}
