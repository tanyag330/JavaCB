package assignment2;

import java.util.Scanner;

public class pattern1 {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number of rows");
		int num=s.nextInt();
		s.close();
		int d=1;
		int n=1;
		int c=1;
		while(c<=num)
		{
		n=1;
		   while(n<=c)
		{
			System.out.print("1");
			n++;
			d++;
		}
		   System.out.print("\n");
		   c++;
		   
		}
	}


}
