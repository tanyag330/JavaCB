package assignment2;

import java.util.Scanner;

public class simple_interest {
	public static int sim_interest(int p ,int r, int t)
	{
		int Sim=(p*r*t)/100;
		return Sim;
	}
	public static void main(){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the amount");
		int num=s.nextInt();
		System.out.print("Enter the rate");
		int rate=s.nextInt();
		System.out.print("Enter the time");
		int time=s.nextInt();
		s.close();
		float si=sim_interest(num,rate,time);
		System.out.print("Simple interest is "+ si);
	}

}
