import java.util.Scanner;


public class kypad {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("enter number");
		int num=s.nextInt();
		s.close();
		String[] str=keypad(num);
		for(int i=0;i<str.length;i++)
			System.out.println(i+1 +" " + str[i]);
		
	}
	public static String[] keypad(int num)
	{
		if(num==0)
		{
			String []output =new String[1];
			output[0]="";
			return output;
		}
		String[] temp=keypad(num/10);
		String lastdigit=helper(num%10);
		int k=0;
		String[] output=new String[temp.length*lastdigit.length()];
		for(int i=0;i<lastdigit.length();i++)
		{
			for(int j=0;j<temp.length;j++)
			{
				output[k]=temp[j]+lastdigit.charAt(i);
				k++;
			}
		}
		return output;
	}
	 public static String helper(int digit)
	 {
		 switch(digit)
		 {
		 case 2:return "abc";
		 case 3:return "def";
		 case 4:return "ghi";
		 case 5:return "jkl";
		 case 6:return "mno";
		 case 7:return "pqrs";
		 case 8:return "tuv";
		 case 9:return "wxyz";
		 }
	    return "";
	 }
}
