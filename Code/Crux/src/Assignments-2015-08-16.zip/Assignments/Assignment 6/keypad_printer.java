import java.util.Scanner;


public class keypad_printer {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("enter number");
		int num=s.nextInt();
		s.close();
		keypad(num,"");
				
	}
	public static void keypad(int num,String outputsofar)
	{
		if(num==0)
		{
			System.out.println(outputsofar);
			return;
		}
		String lastdigit=helper(num%10);
		
		for(int i=0;i<lastdigit.length();i++)
		{
		  keypad(num/10,lastdigit.charAt(i)+outputsofar);	
		}
	}
	 public static String helper(int digit)
	 {
		 switch(digit)
		 {
		 case 2:return "abc";
		 case 3:return "def";
		 case 4:return "ghi";
		 case 5:return "jkl";
		 case 6:return "mno";
		 case 7:return "pqrs";
		 case 8:return "tuv";
		 case 9:return "wxyz";
		 }
	    return "";
	 }

}
