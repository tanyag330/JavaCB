import java.util.Scanner;


public class merge_sort {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		System.out.print("Enter the size of 2 array");
		int size1=s.nextInt();
		int[] array1=new int[size1];
		System.out.print("Enter the values");
		for(int i=0;i<size1;i++)
		{
			array1[i]=s.nextInt();
		}
		int one=0,two=0;
		s.close();
		System.out.print(merge(array,array1,one,two));
		
		
	}
	public static int merge(int input[],int input1[],int one,int two){
	
			if(two<input1.length&&one <input.length)
			{
				if(input[one]>input1[two])
				{
					return input[two]+merge(input,input1,one,two+1);				
				}
				else
				{
					return input[one]+merge(input,input1,one+1,two);
				}
			}
			if(one<input.length)
			{
				return input[one]+merge(input,input1,one+1,two);
						
			}
			else if(two<input1.length)
			{
				return input[two]+merge(input,input1,one,two+1);
						
			}
			return -1;
				
	}
}
