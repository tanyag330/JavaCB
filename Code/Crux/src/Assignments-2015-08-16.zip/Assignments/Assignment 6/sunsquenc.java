import java.util.Scanner;


public class sunsquenc {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		String str=s.nextLine();
		s.close();
	     String[] strs=returnSubsequence(str);
		for(String s1:strs){
			System.out.println(s1);
		}
		
	}

	public static String[] returnSubsequence(String input){
		String output[];
		if(input.length()==0){
			output=new String[1];
			output[0]="";
			return output;
		}
		String smalloutput[]=returnSubsequence(input.substring(1));
		output=new String[2*smalloutput.length];
	    for(int i=0;i<smalloutput.length;i++){
	    	output[i]=smalloutput[i];
	    	
	    }
	    for(int i=0;i<smalloutput.length;i++){
	    	output[i+smalloutput.length]=input.charAt(0)+smalloutput[i];
	    	}
	 return output;
	}
}
