import java.util.Scanner;


public class binary_search {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("write total entry ");
		int size=s.nextInt();
		System.out.println("Enter values");
		int[] entry=new int[size];
		for(int i=0;i<size;i++)
		{
			entry[i]=s.nextInt();
		}
		System.out.print("enter the number to find");
		int num=s.nextInt();
		int start=0;
		int end=entry.length-1;
		s.close();
		System.out.print("location of the number is "+location(entry,num,start,end));
	}
	public static int location(int entry[],int num,int start,int end)
	{		
		if(start<end)
		{
			int mid=(start+end)/2;

		if(entry[mid]==num)
		{
			return mid;
		}
		else if(entry[mid]>num)
		{
			return location(entry,num,start,mid);
		}
		else
		{
			return location(entry,num,mid+1,end);
		}
		}
		return -1;
	}

  
}
