import java.util.Scanner;


public class check_if_reverse {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter string 1 ");
		String str=s.nextLine();
		System.out.println("Enter string 2 ");
		String str1=s.nextLine();
		s.close();
		System.out.print(integer(str,str1));

	}
	public static boolean integer(String str,String str1){
		if(str.length()<=1)
		{
			return true;
		}
		
		if(str.charAt(0)!=str1.charAt(str.length()-1))
				{
			      return false;
				}
		return integer(str.substring(1),str1.substring(0,str.length()-1));
	}
     
}
