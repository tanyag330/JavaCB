import java.util.Scanner;


public class geometric_sum {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=s.nextInt();
		double z=0;
		s.close();
		System.out.print(integer(z,num));
	}
	public static double integer(double ans,int num){
		if(num==0)
		{
			return ans+1;
		}
		return ans+1/Math.pow(2,num)+integer(ans,num-2);


	}


}
