import java.util.Scanner;


public class x_notshow {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=s.nextLine();
	   	s.close();
		System.out.print(integer(str));
		
	}
	public static String integer(String str){
		if(str.length()<1)
		{
			return str;
		}
		else if(str.charAt(0)=='x')
		{
			return integer(str.substring(1));
		}
		return str.substring(0,1).concat(integer(str.substring(1)));
	}	
}
