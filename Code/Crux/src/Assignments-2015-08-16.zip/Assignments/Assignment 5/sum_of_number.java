import java.util.Scanner;


public class sum_of_number {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=s.nextInt();
		int sum=0;
		int e=0;
		s.close();
		System.out.print(integer(num,sum,e));
		
	}
	public static int integer(int n,int sum,int s){
		
		if(n==0)
		{
			return sum; 
		}
		s=n%10;
		return sum+s+integer(n/10,sum,s);			
		

	}
}
