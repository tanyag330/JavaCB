import java.util.Scanner;


public class check_palindrome {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=s.nextLine();	
		s.close();
		System.out.print(integer(str));

	}
	public static boolean integer(String str){

		if(str.length()<=1)
		{
			return true;
		}
		else if(str.charAt(0)!=str.charAt(str.length()-1))
		{
			return false;

		}
		return integer(str.substring(1, str.length()-1));	
	}

}
