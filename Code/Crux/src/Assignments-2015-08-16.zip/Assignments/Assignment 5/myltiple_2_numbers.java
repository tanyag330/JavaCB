import java.util.Scanner;


public class myltiple_2_numbers {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=s.nextInt();
		System.out.println("Enter a number");
		int num1=s.nextInt();
		s.close();
		System.out.println(integer(num,num1));
		
	}
	public static int integer(int m,int n){
		if(n==0)
		{
			return 0;
		}
		return m+integer(m,n-1);
	}
		

}
