import java.util.Scanner;


public class check_zer0 {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=s.nextInt();
		s.close();
		int t=0;
		int e=0;
		System.out.print(integer(num,t,e));
		
	}
	public static String integer(int n,int t,int s){
		
		if(n==0)
		{
			return "total number of zero are "+t;
		}
		s=n%10;
		if(s==0)
		{
			t++;
		}
		return integer(n/10,t,s);
	
	}
}
