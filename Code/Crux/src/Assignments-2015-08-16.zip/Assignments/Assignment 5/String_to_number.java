import java.util.Scanner;


public class String_to_number {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String num=s.nextLine();
		s.close();
		System.out.print(convertString(num));
	}
	public static int convertString(String str){

		if(str.length()==1)
		{
			return str.charAt(0)-'0';
		}
		int smalloutput=convertString(str.substring(0, str.length()-1));
		int lastdigit=str.charAt(str.length()-1)-'0';
		return smalloutput*10+lastdigit;

	}
}
