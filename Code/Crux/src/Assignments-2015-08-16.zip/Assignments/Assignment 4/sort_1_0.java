import java.util.Scanner;


public class sort_1_0 {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		int nextzero=0;
		System.out.print("enter size");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter array");
		for(int i=0;i<size;i++)	
		{
		array[i]=s.nextInt();
		}
		for(int i=0;i<size;i++)
		{
			if(array[i]==0){
				array[nextzero]=0;
				array[i]=1;
				nextzero++;
			
			}
		}
		for(int i=0;i<size;i++){
			System.out.print(array[i]);
		}
		
		
	}

}
