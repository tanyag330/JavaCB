import java.util.Scanner;


public class largest_word {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter character ");
		String word=s.nextLine();
		s.close();
	String[] high=highest(word);
	for(int i=0;i<high.length;i++)
		System.out.print(high[i]);
    }
	
    public static String[] highest(String word){
    	int f=0;
    	int max=0;
    	int h=0;
     	int e=0;
    	for(int i=0;i<word.length();i++)
    	{
    		if(word.charAt(i)!=' ')
    		{
    		 			f++;
    		}
    		else
    			f=0;
    		
    		if(f>max)
    		{
    			max=f;
    			e=i-f;
    		}
    	}
    		String[] higher=new String[max];

    		for(int c=e+1,j=0;j<max;c++,j++){
    			h=c+1;
    			 higher[j]=(word.substring(c,h));
    		}
    		return higher;
    		
    		
    	} 	
 	
    

}
