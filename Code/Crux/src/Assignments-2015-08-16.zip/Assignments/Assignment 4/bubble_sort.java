import java.util.Scanner;


public class bubble_sort {
	public static void main(String args[]){		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		s.close();
		bubble_sorting(array);		
	}
	public static void bubble_sorting(int array[])
	{
		
		for(int i=0;i<array.length-1;i++)
		{
			for(int j=0;j<array.length-i-1;j++)
			{ 
				
				if(array[j]>array[j+1])
				{
					int temp=array[j+1];
					array[j+1]=array[j];
					array[j]=temp;
				}
				
			}
			
		}
		for(int i=0;i<array.length;i++)
		{
			System.out.print(array[i]+" ");
		}
	}

}
