import java.util.Scanner;


public class minimum_length {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter character ");
		String word=s.nextLine();
		s.close();
	      int a,minl=word.length();
          String x=" ",minw=" ";
          char ch;
        
          for(int i=0;i<word.length();i++)
          {
        	  ch=word.charAt(i);
        	  if(ch!=' ')
        	  {
        		  x=x+ch;
        	  }
        	  else
        	  {
        		  a=x.length();
        		  if(a<minl)
        		  {
        			  minl=a;
        			  minw=x;
        		  }
        		  x=" ";
        	  }
        	 
        	  
          		
    	 } 	
          System.out.print(minw);
 	

    }
}



