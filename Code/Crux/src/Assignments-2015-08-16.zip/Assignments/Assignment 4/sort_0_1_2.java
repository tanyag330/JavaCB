import java.util.Scanner;


public class sort_0_1_2 {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		int nextzero=0;
		System.out.print("enter size");
		int size=s.nextInt();
		int[] array=new int[size];
		int nexttwo=size-1;

		System.out.print("Enter array");
		for(int i=0;i<size;i++)	
		{
			array[i]=s.nextInt();
		}
		s.close();
		int temp;
		int i=0;
		while(i<=nexttwo)
		{
			if(array[i]==0){
				temp=array[nextzero];
				array[nextzero]=array[i];
				array[i]=temp;
				nextzero++;	
				i++;
			}
			else if(array[i]==2)
			{	
				temp=array[nexttwo];
				array[nexttwo]=array[i];
				array[i]=temp;
				nexttwo--;
			}
			else 
				i++;
				
		}		

		for( i=0;i<size;i++){
			System.out.print(array[i]);
		}


	}

}
