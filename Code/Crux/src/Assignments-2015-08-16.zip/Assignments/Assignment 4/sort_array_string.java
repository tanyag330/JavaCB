import java.util.Scanner;


public class sort_array_string {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter length");
		int size=s.nextInt();
		String[] array=new String[size];
		for(int i=0;i<size;i++)
			array[i]=s.next();
		s.close();
		for(int i=0;i<array.length;i++)
		{
			{
				for(int j=0;j<array.length-i-1;j++)
				{ 
					
					if(array[j].length()>array[j+1].length())
					{
						String temp=array[j+1];
						array[j+1]=array[j];
						array[j]=temp;
					}
					
				}
				
			}
		}
		for(int i=0;i<array.length;i++)
			System.out.print(array[i]);
	}
}
