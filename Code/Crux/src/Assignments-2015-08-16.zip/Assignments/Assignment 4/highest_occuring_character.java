import java.util.Scanner;


public class highest_occuring_character {
		public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter character ");
		String word=s.nextLine();
		s.close();
	  char[] high=highest(word);
			System.out.print(high);
    }
	
    public static char[] highest(String word){
    	int temp=0;
    	int count=0;
    	int current=0;
     	char[] maxchar=new char[word.length()];
     	char[] c=new char[0];
     	
     			for(int i=0;i<word.length();i++)
    	{
    		char a=word.charAt(i);
    		for(int j=i+1;j<word.length();j++)
    		{
    			if(a==word.charAt(j))
    			{
    				count++;
    			}
    		}
    		if(count>temp)
    		{
    			temp=count;
    			maxchar[current]=a;
    			
    		}
    	}
     		
     	
    		return maxchar;
    		
    }  
    
    
}