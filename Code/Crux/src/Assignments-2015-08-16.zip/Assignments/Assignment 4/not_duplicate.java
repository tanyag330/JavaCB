import java.util.Scanner;


public class not_duplicate {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter character ");
		String word=s.nextLine();
		s.close();
		char a=0;
	 for(int i=0;i<word.length();i++)
		{    
		
		 		 
		if(a !=word.charAt(i))
		{		     
							System.out.print(word.charAt(i));
							a=word.charAt(i);
		}
		}
		 

}
}
