import java.util.Scanner;


public class tripllet {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		int num;
		System.out.print("Enter the size of array");
		int size=s.nextInt();
		int[] array=new int[size];
		System.out.print("Enter the values");
		for(int i=0;i<size;i++)
		{
			array[i]=s.nextInt();
		}
		System.out.println("Enter the number ");
		num=s.nextInt();
		s.close();
		pair(array,num);
	}
	public static int pair(int input[],int n)
	{
		{
	}
		int sum=0;
		for(int i=0;i<input.length;i++)
		{
			for(int j=i+1;j<input.length;j++)
			{
				for(int k=j+1;k<input.length;k++)
				{
					
				if(input[i]+input[j]+input[k]==n)
				{
					System.out.println(input[i]+"+"+input[j]+"+"+input[k]+"="+n);
				}
				}
			}
		}
		return sum;
		
	}
	

}
