import java.util.Scanner;


public class bonus_question {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter character ");
		String word=s.nextLine();
		s.close();
		int f=1;
		char a=0;
	 for(int i=0;i<word.length();i++)
		{    
		
		 		 
		if(a !=word.charAt(i))
		{		
			if(f != 1)
			System.out.print(f);	     
			System.out.print(word.charAt(i));		
			a=word.charAt(i);
			
			f=1;
		}
			else
			{
				f++;
			}
		
		}
		 

}

}
