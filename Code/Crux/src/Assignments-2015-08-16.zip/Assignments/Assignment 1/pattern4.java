import java.util.Scanner;


public class pattern4 {
	public static void main(){
		
	Scanner s=new Scanner(System.in);
	System.out.print("Enter number of rows");
	int num=s.nextInt();
	s.close();
	int row=1;
	while(row<=num/2)
	{
		int space=1;
		while(space<=(num-row))
				{
			System.out.print("*");
			space=space+1;
			
				}
		int value=row;
		int f=0;
		while(value<=(2*row)-1){
			System.out.print(" ");
			value++;
		}
		int decvalue=2*row-2;
		while(decvalue>=row)
		{
			System.out.print(" ");
			decvalue--;
		}
		System.out.println();
		row=row+1;
	}
	while(row<=num/2)
	{
		int space=1;
		while(space<=(num-row))
				{
			System.out.print(" ");
			space=space+1;
			
				}
		int value=row;
		int f=0;
		while(value<=(2*row)-1){
			System.out.print("*");
			value++;
		}
		int decvalue=2*row-2;
		while(decvalue>=row)
		{
			System.out.print("*");
			decvalue--;
		}
		while(value<=(2*row)-1){
			System.out.print(" ");
			value++;
		}
		System.out.println();
		row=row+1;
	}
	}	
}



