import java.util.Scanner;


public class pattern2 {
	public static void main(){
		
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number of rows");
		int num=s.nextInt();
		s.close();
		int row=1;
		int f=num;
		while(row<=num)
		{
			int space=1;
			while(space<=(num-row))
					{
				System.out.print(" ");
				space=space+1;
				
					}
			int value=row;
			while(value<=(2*row)-1){
				
				System.out.print(f);
				value++;
			}
			int decvalue=2*row-2;
			while(decvalue>=row)
			{
				System.out.print(f);

				decvalue--;
			}
			System.out.println();
			row=row+1;
			f--;
		}
		}	
	}

