import java.util.Scanner;


public class pattern3 {
	public static void main(){
		
	Scanner s=new Scanner(System.in);
	System.out.print("Enter number of rows");
	int num=s.nextInt();
	s.close();
	int row=1;
	while(row<=num)
	{
		int space=1;
		while(space<=(num-row))
				{
			System.out.print(" ");
			space=space+1;
			
				}
		int value=row;
		int f=0;
		while(value<=(2*row)-1){
			if(f==0)
			System.out.print("1");
			System.out.print("0");
			value++;
		}
		int decvalue=2*row-2;
		while(decvalue>=row)
		{
			if(decvalue!=row)
			System.out.print("0");
			else
		    System.out.print("1");

			decvalue--;
		}
		System.out.println();
		row=row+1;
	}
	}	

}
