import java.util.Scanner;


public class sum_or_product {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Choose a number:");
		int n=s.nextInt();
		System.out.print("press 1 for product\npress 2 for sun");
		int c=s.nextInt();
		int d=n;
		s.close();
		if(c==1)
		{
			while(d>0)
			{
				c=c*d;
				d--;
			}
			System.out.print("Anser is" + c);
		}
		else if(c==2)
		{
			while(d>0)
			{
				c=c+d;
				d--;
			}
			System.out.print("Anser is" + c);
		}
		else
		{
			System.out.print("Wrong Choice");
		}
	}

}
