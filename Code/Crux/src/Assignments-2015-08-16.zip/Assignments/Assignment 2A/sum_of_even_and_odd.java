import java.util.Scanner;


public class sum_of_even_and_odd {
	public static void main(){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number:");
		int num=s.nextInt();
		s.close();
		int f=0,odd=0,even=0;		
		while(num>=0)
		{
			int c=num%10;
			f++;
			if(f%2==0)
			{
				odd=odd + c;
			}
			else
			{
				even=even + c;
			}
		}
		System.out.println("odd digit sum is:" + odd);
		System.out.print("even digit sum is:" + even);
	}

}
