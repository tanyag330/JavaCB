import java.util.Scanner;


public class decimal_to_binary {
	public static void main(String args[]){
		System.out.print("Enter binary number= ");
		Scanner s=new Scanner(System.in);
		int num=s.nextInt();
		s.close();
		int d=0,n=0;
		while(num>0)
		{
			d=d*10+(num%2);
			num=num/10;
		}
		System.out.print("Decimal number ="+d);
	}

}
