import java.util.Scanner;


public class reverse_number {
	public static void main(String[] args)
	{
			Scanner s=new Scanner(System.in);
			System.out.print("Enter number:");
			int num=s.nextInt();
			s.close();
			int f=1;
			int n=num;
			while(n/10>0)
			{
				f++;
				n=n/10;
			}
			int[] array=new int[10];
			for(int i=0;i<f;i++)
			{
				int c=num%10;
				array[i]=c;		
				num=num/10;
			}
			for(int i=0;i<f;i++)
			{
				System.out.print(array[i]);			
			}
	}
}
