import java.util.Scanner;


public class x_power {
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.print("Choose a number:");
		int n=s.nextInt();
		System.out.print("choose the power");
		int p=s.nextInt();
		s.close();
		int a=(int)Math.pow(n, p);
		System.out.print("Answer is " + a);
	}

}
