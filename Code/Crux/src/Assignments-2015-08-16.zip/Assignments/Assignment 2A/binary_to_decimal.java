import java.util.Scanner;


public class binary_to_decimal {
	public static void main(String args[]){
		System.out.print("Enter binary number= ");
		Scanner s=new Scanner(System.in);
		int num=s.nextInt();
		s.close();
		int d=0,n=0;
		while(num>0)
		{
			d=(int)(d+((num%10)*Math.pow(2, n)));
			n++;
			num=num/10;
		}
		System.out.print("Decimal number ="+d);
	}

}
