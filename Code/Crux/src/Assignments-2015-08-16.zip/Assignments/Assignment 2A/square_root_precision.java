import java.util.Scanner;


public class square_root_precision {
	public static void ans(int num,int p1){
		double c=1;
		int precision=0;
		double increment=1;
		while(c*c<=num)
		{
			c++;
		}
		c=c-1;
		System.out.println("integral part is " + c);		
		while(precision<=p1)
		{   
			increment=Math.pow(10,-1*precision);
			while(c*c<=num)
			{
				c=c+increment;				
			}
			c=c-increment;
			precision++;
		}
		System.out.println("answer is " + c);
	}

	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=s.nextInt();
		System.out.println("Enter the precision");
		int p=s.nextInt();
		s.close();
		ans(num,p);
	}
}
