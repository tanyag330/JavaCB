import java.util.Scanner;


public class first_20 {
	public static void main(String args[]){
		int i=20,n=1;
		while(n<=i)
		{
			if((3*n+2)%4!=0)
			{
				System.out.print(3*n+2 +" ");
				n++;
			}
			else
			{
				n++;
				i++;
			}
		}
	}

}
