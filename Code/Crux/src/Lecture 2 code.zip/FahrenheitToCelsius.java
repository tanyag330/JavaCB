import java.util.Scanner;


public class FahrenheitToCelsius {

	public static void main(String[] args) {
		
		
		
		Scanner console = new Scanner(System.in);	
		System.out.println("Enter min fahrenheit Value");
		
		System.out.println("Enter max fahrenheit value ");
		int minfahrenheitValue = console.nextInt();
		int maxFahrenheitValue = console.nextInt();
		console.close();
		int fahrenheitValue = minfahrenheitValue;
		while(fahrenheitValue <= maxFahrenheitValue){
			int celsiusValue = (int)((5.0/9.0)*(fahrenheitValue - 32));
			System.out.println(fahrenheitValue+"\t"+celsiusValue);
//			System.out.print("\t");
//			System.out.println(celsiusValue);
			fahrenheitValue = fahrenheitValue + 20;
			
		}
		
	
	}

}
