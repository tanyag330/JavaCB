
public class HelloWorld {

	public static void main(String args[]){
		System.out.print("abc");
		System.out.println("Hello World");
		System.out.print("Hello");
		
		
	}
	
}
