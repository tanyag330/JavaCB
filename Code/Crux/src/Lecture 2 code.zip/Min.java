import java.util.Scanner;


public class Min {

	public static void main(String args[]){
		Scanner s = new Scanner(System.in);
		int first,second,third,four,five;
		System.out.println("Enter 5 Numbers ");
		/*first = s.nextInt();
		
		second = s.nextInt();
		
		third = s.nextInt();
		
		four = s.nextInt();
		
		five = s.nextInt();*/
		
		//int min = first;
		int i = -1,j=-1;
		if(i < 0 || j >0)
			System.out.println("Inside if");
			i++;
		else if(i== 2){
			System.out.println("Inside else if");
		}
		else{
			System.out.println("Inside else");
		}
		
	/*	if(second < min){
			min = second;
		}
		if(third < min){
			min = third;
		}
		if(four < min){
			min = four;
		}
		if(five < min){
			min = five;
		}	
		System.out.println("Min is : "+ min);
		*/
		
		
	}
	
}
