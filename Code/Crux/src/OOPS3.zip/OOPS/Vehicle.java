package OOPS;

 public class Vehicle implements CompareInterface<Vehicle>{
	protected double price;
	double maxSpeed;
	public String brand;
	private int numWheels;
	
	public Vehicle(double price){
	this.price = price;
		System.out.println("In Vehicle");
	}
	
	public Vehicle(){
		
	}
	

	public int compareTo(Vehicle v){
		if(price == v.price){
			return 0;
		}
		else if(price > v.price){
			return 1;
		}
		else{
			return -1;
		}
		
	}
	
	 void printDescription(){
		System.out.println("Vehicle :" +brand + maxSpeed + numWheels);
	}


}
