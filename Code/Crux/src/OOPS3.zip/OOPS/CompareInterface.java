package OOPS;

public interface CompareInterface<T> {

	int compareTo(T t);
	
}
