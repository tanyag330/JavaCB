package OOPS;

public class Student {
	public String name;
	private final int rollNo;
	private int phoneNumber;
	private String address;
	private static int numStudents;
	private int marks;
	Batch b;
	
	 Student(String name, Batch b){
		this.name = name;
		numStudents++;
		rollNo = 1000 + numStudents;
		this.b = b;
	}
	
	public  Student(){
		rollNo = 1000 + numStudents;
	 }
	 
	public String getName(){
		
			return name;
		}
	
	public void setBatch(Batch b){
		this.b = b;
	}
	
	public  void setPhoneNumber(int num){
		phoneNumber = num;
	}
	
	public  int getPhoneNumber(int num){
		 return phoneNumber;
	}
	
	public int getRollNo(){
		return rollNo;
		
	}
	

	
}
