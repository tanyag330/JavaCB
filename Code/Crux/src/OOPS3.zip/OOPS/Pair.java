package OOPS;

public class Pair<T>{
	T first;
	T second;
	int a;
	
	public T getFirst(){
		return first;
	}
	public T getSecond(){
		return second;
	}
	
}
