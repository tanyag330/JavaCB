package OOPS;

 class VehicleUse {
	 int a;
	
	 public static void takeVehicle(VehicleInterface v){
		String s =  v.getVehicleType();
	 }
	 
	 
	 public boolean equals(VehicleUse v){
		// FileNotFoundException a = new FileNotFoundException();
		 return true;
	 }
	 
	public static void main(String args[]){
	
	//v.printDescription();
		
	Car c = new Car();
	Truck t = new Truck();
	
		takeVehicle(c);
		//takeVehicle(t);
		
	//c.printDescription();
	//Vehicle v = new Vehicle();

//	System.out.println(v);
	/*int i =2;
	
	if(i<2){
		v = new Vehicle();
	}
	else{
		v = new Car();
	}
	v.printDescription();*/
	Vehicle[] v1 = new Vehicle[2];
	v1[0] = new Car();
	v1[1] = new Truck();
	for(int i = 0; i < v1.length; i++){
		v1[i].printDescription();
	}
	
	BMW b = new BMW(122.2, 4);
	}
}
