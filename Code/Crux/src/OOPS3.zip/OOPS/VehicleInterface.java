package OOPS;

public interface VehicleInterface {

	int a = 1;
	String getVehicleType();
	
}
