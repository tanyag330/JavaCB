package OOPS;

import java.util.Scanner;

public class GenericsUse {

	
	public static<T> T method1(T input){
		return input;
	}
	
	
	public static<T extends CompareInterface<T>> void sort(T[] input){
		T temp;
		for(int i =0 ; i < input.length; i++){
			for(int j = 0; j < input.length - i -1;j++){
				if(input[j].compareTo(input[j+1]) == 1){
					temp = input[j];
					input[j] = input[j+1];
					input[j+1] = temp;
				}
			}
			
		}
	}
	
	public static void main(String args[]){
		Pair<Integer> p = new Pair<>(); 
		 
		Pair<Pair<Integer>> p1 = new Pair<>();
		
		
		Vehicle v[] = new Vehicle[10];
		for(int i = 0; i < v.length; i++){
			v[i] = new Vehicle();
			v[i].price = 100 - i;
		}
			
		sort(v);
		for(int i =0; i < v.length; i++){
			System.out.println(v[i].price);
		}
		
		//p1.first = 1;
		
	}
	
}
