package OOPS;

public class Pair1 {
		Object first;
		Object second;
		
		public Object getFirst(){
			return first;
		}
		public Object getSecond(){
			return second;
		}
	
}
