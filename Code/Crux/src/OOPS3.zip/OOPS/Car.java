package OOPS;

public class Car extends Vehicle implements VehicleInterface,Interface1{

	public int numWindows;
	public int numDoors;
	//public double price;
	
	public Car(double price){
		//super(price);
		this.price = price;
		super.price = 1.233;
		this.numDoors = numDoors;
		System.out.println(price);
	}
	
	
	public Car(){
	
	}
	public int getNumDoors(){
		return numDoors;
	}

   void printDescription(){
		System.out.println("Car : "+brand + maxSpeed + " "+numDoors);
	}


@Override
public String getVehicleType() {
	
	return "Car";
	
}



}
