package OOPS;

public interface Interface1 {

	int a =10 ;
}
