package Java;

public class powerofx {
	public static int power(int x, int n)
	{
		if (n==0)
		{
			return 1;
		}
		return x*power(x,n-1);
	}


	public static void main(String[] args) {
		int number=3;
		int x=3;
		System.out.println(" is "+power(x,number));

	}

}
