package Java;

public class count_zeros {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
