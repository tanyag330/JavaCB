package Java;

public class decimal_binaryconversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
