package Java;

public class series {
	public static void main(String args[])
	{
		int n=1,num,terms=1;
		while(terms<=20)
		{
			num=3*n+2;
			if(num%4!=0)
			{
				terms=terms+1;
			
				System.out.println(num);
			}
			n=n+1;

			}}

}
