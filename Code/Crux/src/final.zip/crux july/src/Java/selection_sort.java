package Java;

import java.util.Scanner;

public class selection_sort {
	public static int [] takeinput()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("enter size of an array");
		int size= s.nextInt();
		int input[]=new int [size];
		System.out.println("enter array");	
		for (int i=0; i<input.length;i++)
		{input [i]= s.nextInt();
		}
		return input;
	}

	public static void printarray(int[] a)
	{
		for(int i=0; i<a.length;i++)
		{
			System.out.print(a[i] +" " );	
		}
	}
	public static void selectionsort(int[] input)
	{

		int min= input[0]; 
		int temp=0;

		for (int i=0; i<input.length ; i++)
		{
			min=i;     		
			for (int j=i+1; j<input.length;j++)
			{
				if(input [j]< input[min]);
				min=j;

				if (min !=i)
				temp= input[i];
				input[i]=input[min];
				input[min]=temp;
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] input= takeinput();
		selectionsort(input);
		printarray(input);
	}

}
