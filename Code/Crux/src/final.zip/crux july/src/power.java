import java.util.Scanner;

public class power {
	public static int power(int n, int x)
	{
		int i,p;
		i=1;
		p=1;
		while(i<=x)
		{
			p=p*n;
			i++;
		}
		return p;
	}
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter n");
		int n=s.nextInt();
		System.out.println("enter x");
		int x=s.nextInt();
		int val = power(n,x);
		System.out.println("power is:"+val);
	}

}
