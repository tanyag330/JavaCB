package Java1;

public class pattern {
	public static void pattern()
	{ 
		int n=9,i,l,j,k,x,y;
		{y=n;
		for(i=1;i<=(y/2)+1;i++)
		{
			if(i==1||i==9)
			{
				for(j=1;j<=9;j++)
				{
					System.out.print("*");
				}
			}
			else
			{
				x=i-1;
				for(k=1;k<=n/2;k++)
				{
					System.out.print("*");
				}
				for(l=1;l<=(2*x-1);l++)
				{
					System.out.print(" ");
				}
				for(k=1;k<=n/2;k++)
				{
					System.out.print("*");
				}
				n=n-2;
			}
			System.out.println();
		}
		}

	}

	public static void main(String args[])
	{
		pattern();
	}

}