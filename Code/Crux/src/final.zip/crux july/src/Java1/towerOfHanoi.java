package Java1;

public class towerOfHanoi {
	
	public static void t4owerOfHanoi(int topN, char from, char to, char inter)
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
