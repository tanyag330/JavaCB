package Data_Structures;

public class BTPair {

	int height;
	int diameter;
	
	BTPair(int height, int diameter){
		this.height = height;
		this.diameter = diameter;
	}
	
}
