package Text_Processing;

public class StringBufferDemo {

	public static void main(String args[]){
		StringBuffer s = new StringBuffer("abc");
		s.
		
	}
	
}
