package Data_Structures;

import java.util.ArrayList;

public class Polynomial {

	private ArrayList<PolyPair> degCoeff;
	private int degree;   // max degree of polynomial
	
	Polynomial(){
		degCoeff = new ArrayList<PolyPair>();
		degree = 0;
	}
	
	public int degree(){
		return degCoeff.get(degCoeff.size()-1).getDegree();
	}
	
	public void setCoefficient(int degree, int coeff){
		
		for(int i =0; i < degCoeff.size(); i++){
			PolyPair currentPair = degCoeff.get(i);
			if(currentPair.getDegree() == degree){
				currentPair.setCoeff(coeff);
				return;
			}
		}
		int pos = degCoeff.size() - 1;
		PolyPair currentPair = degCoeff.get(pos);
		while(pos >= 0 && currentPair.getDegree() > degree){
			pos--;
			currentPair = degCoeff.get(pos);
		}
		PolyPair newPair = new PolyPair(degree,coeff);
		degCoeff.add(pos+1, newPair);
	}
	
	public Polynomial add(Polynomial p){
		
	}
	
}
