package OOPS;

 abstract public class Vehicle {
	protected double price;
	double maxSpeed;
	public String brand;
	private int numWheels;
	
	public Vehicle(double price){
	this.price = price;
		System.out.println("In Vehicle");
	}
	
	public Vehicle(){
		
	}
	
	
	
	 void printDescription(){
		System.out.println("Vehicle :" +brand + maxSpeed + numWheels);
	}
	 
	abstract String getType();
	
	
}
