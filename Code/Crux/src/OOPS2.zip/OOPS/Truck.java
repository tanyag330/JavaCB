package OOPS;

public class Truck extends Vehicle {

	public void printDescription(){
		System.out.println("Truck :" +brand + maxSpeed);
	}

	@Override
	String getType() {
		// TODO Auto-generated method stub
		return "Truck";
	}
	
}
