package OOPS;

final class BMW extends Car{

	BMW(double price1, int numDoors){
		super(price1);
	}
	
	 void printDescription(){
		System.out.println("Car : "+brand + maxSpeed + " "+numDoors);
	}
	
}
