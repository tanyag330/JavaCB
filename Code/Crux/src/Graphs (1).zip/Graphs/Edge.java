package Graphs;

public class Edge {
	Vertex first;
	Vertex second;
	
}
