package OOPS;

public class StudentUse{

	public static void main(String args[]){
		Student s1 = new Student("Manisha");
	//	s1.name = ;
		//s1.rollNo = 1001;
		//s1.phoneNumber = 9199;
	//	Student.numStudents++;
		System.out.println(s1.name +" "+s1.getRollNo() + " ");
	//	s1.rollNo = 1111;
	//	Student.incrementCount();
		s1 = new Student("Abc",103);
		System.out.println(s1.name +" "+s1.getRollNo() + " ");
		
		
		Student s2 = new Student("Mayank",102);
	//	s2.name = ";
	//	s2.rollNo = 1002;
		s2.setPhoneNumber(9198);
	//	Student.numStudents =0;
	//	Student.incrementCount();
		//System.out.println(s2.name +" "+s2.getRollNo() + " "+s1.numStudents);
		
		
	}
	
}
