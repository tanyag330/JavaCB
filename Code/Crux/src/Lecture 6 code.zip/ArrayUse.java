import java.util.Scanner;


public class ArrayUse {

	public static int[] takeInput(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter size of Array :");
		int size = s.nextInt();
		int input[] = new int[size];
		System.out.println("Enter Array ");
		for(int i = 0; i < size; i++){
			input[i] = s.nextInt();
		}
		//	s.close();
		return input;	
	}


	public static void printArray(int[] arr){
		for(int i = 0; i < arr.length; i++){
			System.out.print(arr[i]+" ");
		}
	}

	// input1 = {1,2,3,4,5}
	public static void increment(int[] input1){
		//input1 = new int[5];
		for(int i = 0; i < input1.length; i++){
			input1[i] = input1[i] + 1;
		}
		printArray(input1);
	}


	public static int binarySearch(int[] input, int element){

		int beg = 0;
		int end = input.length - 1;
		int mid;

		while(beg<=end){
			mid = (beg + end) / 2;

			if(input[mid] == element){
				return mid;
			}
			else if(input[mid] > element){
				end = mid - 1;
			}
			else{
				beg = mid+1;
			}
		}

		return -1;	
	}


	public static int[][] takeInput2D(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter first dimension");
		int m = s.nextInt();
		System.out.println("Enter second dimension");
		int n = s.nextInt();
		int[][] input = new int[m][n];

		for(int i = 0; i < m; i++){
			for(int j = 0; j < n; j++){
				System.out.println("Enter element in "+i+" row and "+j+" column :"); 
				input[i][j] = s.nextInt();
			}
		}
		return input;
	}

	public static void print2DArray(int[][] input){
		int m = input.length;
		int n = input[0].length;

		for(int i = 0; i < m; i++){
			for(int j = 0; j < n; j++){
				System.out.print(input[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void insertionSort(int input[]){
		int temp;
		int j;
		for(int i = 0; i < input.length; i++){
			j = i-1;
			temp = input[i];
			while(j>=0 && input[j]>temp){
				input[j+1] = input[j];
				j--;
			}
			j++;
			input[j] = temp;
		}
	}
	
	
	public static void sortZeroOnes(int input[]){
		int nextZero = 0;
		int temp;
		for(int i = 0; i < input.length; i++){
			if(input[i]==0){
				temp = input[nextZero];
				input[nextZero] = input[i];
				input[i] = temp;
				nextZero++;
			}

		}
		
	}
	
	public static void sortZeroOnes_2(int[] input){
		
		int i = 0;
		int j = input.length - 1;
		
		while(i < j ){
			if(input[i] == 0){
				i++;
			}
			else if(input[j] == 1){
				j--;
			}
			else{
				int temp = input[i];
				input[i] = input[j];
				input[j] = temp;
				i++;
				j--;
			}
			
		}	
	}
	
	public static void mergeSort(int input[]){
		if(input.length <= 1){
			return;
		}
		
		int beg = 0;
		int end = input.length -1;
		int mid = (beg + end) / 2;
		int half1[] = new int[mid + 1];
		int half2[] = new int[end - mid];
		for(int i = 0; i <= mid; i++){
			half1[i] = input[i];
		}
		for(int i = mid+1,k=0; i <= end; i++,k++){
			half2[k] = input[i];
		}
		mergeSort(half1);
		mergeSort(half2);
		int temp[] = merge(half1,half2);
		for(int i =0; i < temp.length; i++){
			input[i] = temp[i];
		}	
	}

	public static int[] merge(int arr1[], int arr2[]){
		int i = 0;
		int j = 0;
		int k = 0;
		int output[] = new int[arr1.length + arr2.length];
		
		while(i < arr1.length && j < arr2.length){
			if(arr1[i] < arr2[j]){
				output[k] = arr1[i];
				i++;
				k++;
			}
			else {
				output[k] = arr2[j];
				j++;
				k++;
			}
		}
		
		while(i < arr1.length){
			output[k] = arr1[i];
			i++;
			k++;
		}
		
		while(j < arr2.length){
			output[k] = arr2[j];
			j++;
			k++;
		}
		
		return output;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//	int[] input1 = new int[5];
		//input1[0] = 1;

		//int[] input1 = {1,2,3,4,5};
		//m	input1 = {2,3,4,5,6}; 

		Scanner s1 = new Scanner(System.in);
		//String a = s1.next();
	int[] input = takeInput();
	//insertionSort(input);
     mergeSort(input);
	printArray(input);
	
	
	
	/*int input2[] = takeInput();
	
	int output[] = merge(input, input2);
	printArray(output);*/
	
	/*sortZeroOnes(input);
	printArray(input);*/
		/*printArray(input);
		System.out.println();
		increment(input);*/
		//	printArray(input1);
		//System.out.println();

		//int input[] = {1,2,3,4,5};
		/*System.out.println("Enter element to be searched");
		int element  = s1.nextInt();
		int element = 4;
		System.out.println(binarySearch(input, element));*/


		/*int[][] input2D = takeInput2D();
		print2DArray(input2D);*/
		
	
	}

}
