
public class Recursion {

	public static int factorial(int n){
		if(n == 0){
			return 1;
		}
		return n*factorial(n-1);
	}


	public static int fib(int n){
		if(n==1 || n==2){
			return 1;
		}
		return fib(n-1) + fib(n-2);
	}

	public static int power(int x, int n){
		if(n==0){
			return 1;
		}
		return x*power(x, n-1);
	}

	public static boolean checkSorted(int[] input){
		int n = input.length;
		if(n==1 || n==0){
			return true;
		}
		if(input[0] > input[1]){
			return false;
		}
		int smallInput[] = new int[n-1];
		for(int i = 1; i < n; i++){
			smallInput[i-1] = input[i];
		}
		//	boolean smallOutput = 
		return checkSorted(smallInput);
	}
	// check sorted from beginIndex to End
	public static boolean checkSorted_1(int[] input,int beginIndex){
		if(beginIndex >= input.length-1){
			return true;
		}
		if(input[beginIndex] > input[beginIndex+1]){
			return false;
		}

		return checkSorted_1(input,beginIndex+1);
	}

	
	public static String addStars(String input){
		if(input.length() < 2){
			return input;
		}
		
		String smallOutput = addStars(input.substring(1));
		//String output;
		
		if(input.charAt(0) == input.charAt(1)){
			return input.charAt(0) + "*" + smallOutput;
		}
		else{
			return input.charAt(0) + smallOutput;
		}
	}
	
	public static int[] returnIndicesOfNumber(int[] input,int beginIndex, int num){
		int[] output;
		if(beginIndex >= input.length){
			output = new int[0];
			return output;
		}
		
		
		int smallOutput[] = returnIndicesOfNumber(input, beginIndex + 1, num);
		if(input[beginIndex] != num){
			return smallOutput;
		}
		else{
			output = new int[smallOutput.length + 1];
			for(int i = 0; i < smallOutput.length; i++){
				output[i] = smallOutput[i];
			}
			output[smallOutput.length] = beginIndex;
			return output;
		}
		
	}
	
	
	public static void selectionSortR(int[] input, int beginIndex){
		if(beginIndex >= input.length -1){
			return;
		}
		
		int min = input[beginIndex];
		int pos = beginIndex;
		
		for(int i = beginIndex + 1; i < input.length; i++){
			if(input[i] < min){
				min = input[i];
				pos = i;
			}
		}
		if(pos != beginIndex){
			int temp = input[beginIndex];
			input[beginIndex] = min;
			input[pos] = temp;
		}
		selectionSortR(input, beginIndex+1);
	}
	

	public static void main(String args[]){
		int number =5;
		//	System.out.println(factorial(number));
		System.out.println(number +" term is :"+ fib(number));


		int input[] = {5,4,3,2,1};
		/*boolean result = checkSorted_1(input, 0);
		System.out.println(result);*/
		
		selectionSortR(input, 0);
		for(int i = 0; i < input.length; i++){
			System.out.println(input[i]);
		}
		
		/*int[] output = new int[input.length];
		
		for(int i = 0; i < input.length; i++){
			output[i] = -1;
		}*/
		
	//	returnIndices7(input,0,output,outputIndex);
		
		

	}
}