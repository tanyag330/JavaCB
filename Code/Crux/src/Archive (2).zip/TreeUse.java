package Data_Structures;

import java.util.Scanner;

public class TreeUse {


	public static TreeNode<Integer> takeInput(){
		Scanner s = new Scanner(System.in);

		System.out.println("Enter root data :");
		int rootData = s.nextInt();
		TreeNode<Integer> root = new TreeNode<Integer>(rootData);
		System.out.println("Enter number of children of "+rootData+" : ");
		int numChild = s.nextInt();

		for(int i = 0; i < numChild; i++){
			TreeNode<Integer> currentChild = takeInput();
			root.children.add(currentChild);
		}
		return root;
	}

	public static TreeNode<Integer> takeInputLevelWise(){
		Scanner s = new Scanner(System.in);
		QueueUsingLL<TreeNode<Integer>> pendingNodes = new QueueUsingLL<TreeNode<Integer>>();
		
		System.out.println("Enter root data :");
		int rootData = s.nextInt();
		TreeNode<Integer> root = new TreeNode<Integer>(rootData);
		pendingNodes.enqueue(root);

		while(!pendingNodes.isEmpty())
		{	
			TreeNode<Integer> currentNode;
			try {
				currentNode = pendingNodes.dequeue();
				System.out.println("Enter number of children of "+currentNode.data+" :");
				int numChild = s.nextInt();	
				for(int i =0; i < numChild; i++){
					System.out.println("Enter "+i+" child of :"+currentNode.data);
					int childData = s.nextInt();
					TreeNode<Integer> child = new TreeNode<Integer>(childData);
					pendingNodes.enqueue(child);
					currentNode.children.add(child);			}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Never reach here ");
			}
			
		}
		return root;
	}

	
	

	public static void print(TreeNode<Integer> root){
		if(root == null){
			return;
		}
		String toBePrinted  = root.data +" : ";

		for(int i = 0; i < root.children.size(); i++){
			TreeNode<Integer> currentChild = root.children.get(i);
			toBePrinted+= currentChild.data +", ";
		}
		System.out.println(toBePrinted);

		for(int i = 0; i < root.children.size(); i++){
			TreeNode<Integer> currentChild = root.children.get(i);
			print(currentChild);
		}
	}
	
	
	public static void printLevelWise(TreeNode<Integer> root) throws Exception{
		if(root == null){
			return;
		}
		
		QueueUsingLL<TreeNode<Integer>> pendingNodes = new QueueUsingLL<TreeNode<Integer>>();
		pendingNodes.enqueue(root);
		
		while(!pendingNodes.isEmpty()){
			TreeNode<Integer> currentNode = pendingNodes.dequeue();
			String toBePrinted = currentNode.data + " : ";
			/*for(int i =0; i < currentNode.children.size(); i++){
				TreeNode<Integer> currentChild = currentNode.children.get(i);
				toBePrinted += currentChild.data +", ";
				pendingNodes.enqueue(currentChild);
			}*/
			
			for(TreeNode<Integer> child : currentNode.children){
				toBePrinted += child.data +", ";
				pendingNodes.enqueue(child);
			}
			
			System.out.println(toBePrinted);
			
		}
		
	}

	
	public static int countNodes(TreeNode<Integer> root){
		
		if(root == null){
			
		}
		
		int count = 1;
		for(TreeNode<Integer> child : root.children){
			int numNodesInChild = countNodes(child);
			count = count + numNodesInChild;
		}
		
		return count;
	}
	
	public static TreeNode<Integer> findLargest(TreeNode<Integer> root){
	
		TreeNode<Integer> max = root;
		for(TreeNode<Integer> child : root.children){
			TreeNode<Integer> maxInChild = findLargest(child);
			if(maxInChild.data > max.data){
				max = maxInChild;
			}
		}
		return max;
	}
	
	public static void printAtDepthK(TreeNode<Integer> root, int depth){
		
		if(root == null){
			return;
		}
		if(depth == 0){
			System.out.println(root.data);
		}
		
		for(TreeNode<Integer> child : root.children){
			printAtDepthK(child, depth - 1);
		}	
		
	}
	
	
	public static void main(String args[]) throws Exception{
		TreeNode<Integer> root = takeInputLevelWise();
		print(root);
		System.out.println("Number of nodes are "+ countNodes(root));
		printAtDepthK(root, 2);
	}

}
