import java.util.Scanner;

//import java.util.Scanner;


public class CheckPrime {


	public static void isPrime(int num){
		int divisor = 2;
		while(divisor < num){
			if(num % divisor == 0){
				System.out.println("Not Prime");
				return;
			}
			divisor++;
		}
			System.out.println("Prime");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number :");
		int num = s.nextInt();
		//boolean  result = 
		isPrime(num);
		/*if(result){
			System.out.println("Prime");
		}
		else{
			System.out.println("Not Prime");
		}*/
	}
}
