import java.util.Scanner;


public class HelloWorld {

	public static void main(String args[]){
		/*System.out.print("abc");
		System.out.println("Hello World");
		System.out.print("Hello");*/
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number of elements in the sequence :");
		int n = s.nextInt();
		int i = 1;
		boolean isDec = true;
		int prev = Integer.MAX_VALUE,current;
		while(i <= n){
			current = s.nextInt();
			if(isDec && current > prev){
				isDec = false;
			}
			
			if(!isDec && current < prev){
				System.out.println("Invalid Sequence ");
				return;
			}
			prev = current;
			i++;
		}
	//	if(i==n){
			System.out.println("Valid Sequence");
		//}
	}
	
}
