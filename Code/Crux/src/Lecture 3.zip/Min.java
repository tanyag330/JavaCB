import java.util.Scanner;


public class Min {

	public static int findMin(int first, int second, int third){
		int min = first;
		if(second < min){
			min = second;
		}
		if(third < min){
			min = third;
		}
		return min;
	}
	
	/*public static void a(){
		System.out.println(first);
	}*/
	
	public static void main(String args[]){
		Scanner s = new Scanner(System.in);
		int first,second,third;
		System.out.println("Enter 3 Numbers ");
		first = s.nextInt();
		
		second = s.nextInt();
		
		third = s.nextInt();
		
		/*four = s.nextInt();
		
		five = s.nextInt();
		*/
		
		/*int i = -1,j=-1;
		if(i < 0 || j >0)
			System.out.println("Inside if");
			i++;
		else if(i== 2){
			System.out.println("Inside else if");
		}
		else{
			System.out.println("Inside else");
		}*/
		
	
		/*if(four < min){
			min = four;
		}
		if(five < min){
			min = five;
		}	*/
		
		int minimum = findMin(first, second, third);
		
	/*	System.out.println("Min is : "+ minimum);
		int j = 0;
		while(j < 4){
			j++;
		}
		System.out.println(j);*/
		int a = 4;
		if(a==4){
			int j = 10;
		}
		else{
			int j = 10;
			System.out.println(j);
		}
	//	int a = 10;
		/*if()
		
		for(int i = 4; i > 0; i--){
			int a = 10;
			System.out.println(a);
			a++;
		}
	//	System.out.println(i);
*/		
	}
	
}
