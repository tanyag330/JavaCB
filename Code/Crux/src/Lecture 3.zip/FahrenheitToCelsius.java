import java.util.Scanner;


public class FahrenheitToCelsius {
	
	public static void printCelsiusValues(int minFahrenheitValue, int maxFahrenheitValue, int step){
		int fahrenheitValue = minFahrenheitValue;
		while(fahrenheitValue <= maxFahrenheitValue){
			int celsiusValue = (int)((5.0/9.0)*(fahrenheitValue - 32));
			System.out.println(fahrenheitValue+"\t"+celsiusValue);
			fahrenheitValue = fahrenheitValue + step;
		}
	}
	

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);	
		System.out.println("Enter min fahrenheit Value");
		int minFahrenheitValue = console.nextInt();
		System.out.println("Enter max fahrenheit value ");
		int maxFahrenheitValue = console.nextInt();
		System.out.println("Enter step size ");
		int step = console.nextInt();
	//	console.
	//	console.close();
		printCelsiusValues(minFahrenheitValue, maxFahrenheitValue, step);
		System.out.println("abc");
	}

}
