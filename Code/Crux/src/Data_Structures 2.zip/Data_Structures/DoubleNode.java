package Data_Structures;

public class DoubleNode {
	Node<Integer> head;
	Node<Integer> tail;
	

}
