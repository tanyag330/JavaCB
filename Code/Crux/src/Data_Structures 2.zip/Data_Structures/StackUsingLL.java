package Data_Structures;

public class StackUsingLL<T> {

	private Node<T> head;
	private int size;
	
	
}
