package Data_Structures;

public class IndexOutofBoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
