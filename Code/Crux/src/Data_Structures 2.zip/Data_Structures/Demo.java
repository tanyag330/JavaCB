package Data_Structures;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Node<Integer> node1 = new Node<>();
		Node<String> node2 = new Node<>();
	}

}
