package Data_Structures;

public class Node<T> {
	T data;
	Node<T> next;
}
